﻿
using System.Windows;


namespace SampleApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public static readonly RoutedEvent SomethingHappenedEvent = 
            EventManager.RegisterRoutedEvent("SomethingHappened",RoutingStrategy.Bubble,typeof(RoutedEventHandler),typeof(MainWindow));
        public event RoutedEventHandler SomethingHappened
        {
            add { AddHandler(SomethingHappenedEvent, value); }
            remove { RemoveHandler(SomethingHappenedEvent, value); }
        }

        public void RaiseChangedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(MainWindow.SomethingHappenedEvent);
            RaiseEvent(args);
        }


    }
}
